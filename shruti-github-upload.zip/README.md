Upload ALL files in this folder to the root of your GitHub repo (no sub-folders).
Then Settings > Pages > Deploy from branch > main / root.
Do not upload shruti-preview.html.
