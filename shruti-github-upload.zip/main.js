const S=window.SITE,$=s=>document.querySelector(s),L=S.links,prm=matchMedia('(prefers-reduced-motion:reduce)').matches;
const esc=t=>String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const I={youtube:'<rect x="2.5" y="5" width="19" height="14" rx="4"/><path d="M10 9l5 3-5 3z"/>',telegram:'<path d="M21 4L3 11l6 2 2 6 3-4 5 4z"/><path d="M9 13l12-9"/>',discussion:'<path d="M4 5h16v11H9l-5 4z"/>',instagram:'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".6"/>',mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>'};
const svg=k=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round">${I[k]}</svg>`;
const NM={youtube:'YouTube',telegram:'Telegram channel',discussion:'Discussion group',instagram:'Instagram',mail:'Email'};
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');setTimeout(()=>t.classList.remove('on'),2200)};
const PGS=['about','ssc','railway'];
let pg=(location.pathname.match(/(about|ssc|railway)\.html$/)||[,'home'])[1];
const route=()=>{const h=location.hash.slice(1);if(PGS.includes(h)||h=='home'){pg=h;scrollTo(0,0)}else if(h.startsWith('policy-')){pg='about';document.body.dataset.page=pg;setTimeout(()=>{const d=document.getElementById(h);if(d){d.open=true;d.scrollIntoView()}},80)}else if(['contact','offer','videos'].includes(h)){pg='home';document.body.dataset.page=pg;setTimeout(()=>document.getElementById(h)?.scrollIntoView(),30)}document.body.dataset.page=pg;if(pg=='about')openLap()};
route();addEventListener('hashchange',route);
$('#logo').innerHTML=`<img src="${S.logo}" alt=""><span class="lg"><span>${esc(S.brand)}</span><small class="tg">${esc(S.tagline)}</small></span>`;
$('#menu').onclick=()=>$('#nav').classList.toggle('open');
document.querySelectorAll('#nav a').forEach(a=>a.onclick=()=>$('#nav').classList.remove('open'));
$('#foot').innerHTML=`<span class="ftag">${esc(S.tagline)}</span><br>© ${new Date().getFullYear()} ${esc(S.brand)}`;

// Social 3D buttons
$('#soc').innerHTML=['youtube','telegram','discussion','instagram'].map(k=>{const u=L[k];return u?`<a href="${u}" target="_blank" rel="noopener" aria-label="${NM[k]}" title="${NM[k]}">${svg(k)}</a>`:`<button data-s="${NM[k]}" aria-label="${NM[k]} (coming soon)" title="${NM[k]}">${svg(k)}</button>`}).join('');
document.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>toast(b.dataset.s+' link coming soon'));

// Target series chooser (rendered twice) + plan pages
const PG={ssc:'ssc.html',railway:'railway.html'};
['#offer'].forEach(id=>{const sc=$(id);sc.innerHTML=`<div class="wrap tsel"><h2>Target series</h2><p class="intro">Select your exam to explore active target series and available plans.</p><div class="opts"><button data-k="ssc">SSC Exams</button><button data-k="railway">Railway Exams</button></div><a class="btn pink go" hidden>Explore Target Series</a><p><button class="btn ghost dk howbtn" type="button">How to Join a Target Series</button></p></div>`;
 sc.querySelectorAll('.opts button').forEach(b=>b.onclick=()=>{sc.querySelectorAll('.opts button').forEach(x=>x.classList.toggle('on',x==b));const g=sc.querySelector('.go');g.href=PG[b.dataset.k];g.hidden=false;g.classList.remove('pop');void g.offsetWidth;g.classList.add('pop')})});
const OS=S.offers,disc=Math.round((1-OS.railway.price/OS.railway.old)*1000)/10;
const PL='<p class="plinks">Before you join, please read: <a href="about.html#policy-terms" target="_blank" rel="noopener">Terms &amp; Conditions</a> · <a href="about.html#policy-refund" target="_blank" rel="noopener">Refund Policy</a> · <a href="about.html#policy-disclaimer" target="_blank" rel="noopener">Disclaimer</a></p>';
const psum=ex=>`<dl class="psum"><div><dt>Examination covered</dt><dd>${ex}</dd></div><div><dt>Access validity</dt><dd>Valid till the exam date of ${ex}. It covers this examination cycle only and does not extend to future examination cycles or other Target Series.</dd></div><div><dt>Programme inclusions</dt><dd><ul><li>Daily study targets and preparation schedules</li><li>Digital study materials and PDFs</li><li>Quizzes and practice resources</li><li>Access to a private Telegram group for updates and communication</li></ul></dd></div><div><dt>Duration</dt><dd>From the day you join until the exam date.</dd></div><div><dt>Refund policy</dt><dd>Refunds are considered for a duplicate payment, a payment made but access not provided, cancellation of the series by us, or a significant service deficiency. There is no refund for a change of mind after access is activated. Read the full <a href="about.html#policy-refund" target="_blank" rel="noopener">Refund Policy</a>.</dd></div></dl>${PL}`;
const HOWB='<p><button class="btn ghost howbtn" type="button">How to Join a Target Series</button></p>';
$('#sscp').innerHTML=`<div class="wrap"><a class="back" href="index.html">← Back to home</a><div class="ocard"><span class="tag">SSC Exams</span><h2>${esc(OS.ssc.title)}</h2><div class="pr"><b>₹${OS.ssc.price}</b></div>${psum('SSC CHSL 2026')}<div class="obtn"><button class="btn pink" id="joinssc" type="button">Join Target Series</button><a class="btn ghost" href="${OS.ssc.video}" target="_blank" rel="noopener">Complete Strategy</a></div></div></div>`;
$('#railp').innerHTML=`<div class="wrap"><a class="back" href="index.html">← Back to home</a><div class="ocard"><span class="tag">Railway Exams</span><h2>${esc(OS.railway.title)}</h2><div class="pr"><s>₹${OS.railway.old}</s><b>₹${OS.railway.price}</b></div><p class="off">${disc}% off</p>${psum('NTPC Graduate 2026')}<button class="btn pink" id="pay" type="button">Join the Series</button></div></div>`;
$('#joinssc').onclick=()=>window.openCko(OS.ssc.title+' · ₹'+OS.ssc.price,OS.ssc.join);
$('#pay').onclick=()=>window.openCko(OS.railway.title+' · ₹'+OS.railway.price,OS.railway.link);
document.querySelectorAll('.ocard').forEach(c=>{c.onpointermove=e=>{const r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform=`rotateY(${x*12}deg) rotateX(${-y*12}deg)`};c.onpointerleave=()=>c.style.transform=''});

// YouTube videos
$('#videos').innerHTML=`<div class="wrap"><h2>Watch the guidance</h2><div class="vg">${S.videos.map(v=>`<a class="vc" href="${v.url}" target="_blank" rel="noopener"><div class="th"><img src="${v.img}" alt="${esc(v.title)}" loading="lazy"><i>▶</i></div><h3 data-id="${v.id}">${esc(v.title)}</h3></a>`).join('')}</div>
<div class="ytrow"><a class="btn pink" href="${L.youtube}?sub_confirmation=1" target="_blank" rel="noopener">Subscribe</a><a class="btn ghost dk" href="${L.youtube}" target="_blank" rel="noopener">Visit YouTube Channel</a></div>
<p class="ytnote">This is my YouTube channel, Shruti: Your Guide, where I share my learnings and strategies with all of you.<strong class="ytag">${esc(S.tagline)}</strong></p></div>`;

// Testimonials: 2D screenshots
const SH=[...S.screens,...S.formshots];
$('#testimonials').innerHTML=`<div class="wrap"><h2>What students say</h2><p class="intro">Real messages and form responses from students. Tap any one to read it in full.</p><div class="tg">${SH.map(t=>`<figure class="ts" tabindex="0" data-i='${JSON.stringify(t.img)}'><img loading="lazy" src="${t.img[0]}" alt="${esc(t.cap)}">${t.img.length>1?'<em>2 parts</em>':''}<figcaption>${esc(t.cap)}</figcaption></figure>`).join('')}</div></div>`;
document.querySelectorAll('.ts').forEach(f=>{const o=()=>{const lb=$('#lb');lb.innerHTML=JSON.parse(f.dataset.i).map(i=>`<img src="${i}" alt="">`).join('')+'<button class="btn pink">Close</button>';lb.showModal()};f.onclick=o;f.onkeydown=e=>e.key=='Enter'&&o()});
$('#lb').onclick=()=>$('#lb').close();
$('#gs').innerHTML='<div class="wrap" style="text-align:center"><a class="btn pink big" href="#offer">GET STARTED</a></div>';

// About page
const polHtml=(()=>{const r=t=>{let o='',ul=0;for(const ln of t.trim().split('\n')){const l=ln.trim();if(l.startsWith('- ')){if(!ul){o+='<ul>';ul=1}o+='<li>'+esc(l.slice(2))+'</li>';continue}if(ul){o+='</ul>';ul=0}if(l)o+=l.startsWith('## ')?'<h3>'+esc(l.slice(3))+'</h3>':'<p>'+esc(l)+'</p>'}return o+(ul?'</ul>':'')};return '<div class="pol">'+S.policies.map(p=>`<details id="policy-${p.id}"><summary>${esc(p.title)}</summary><div class="polb"><p class="upd">Last updated: ${esc(p.updated)}</p>${r(p.text)}</div></details>`).join('')+'</div>'})();
const AS=S.story;
$('#aboutp').innerHTML=`<div class="abh"><div class="wrap"><img class="ablogo" src="${S.logo}" alt="Shruti: Your Guide logo"><div><h1>Why I Started Shruti: Your Guide</h1><p class="abtag">${esc(S.tagline)}</p></div></div></div>
<div class="wrap abb">${AS.map((t,i)=>i==AS.length-1?`<p class="abfin">${esc(t)}</p>`:[2,8].includes(i)?`<blockquote class="abq">${esc(t)}</blockquote>`:i==3?`<p class="abst">${esc(t)}</p>`:`<p>${esc(t)}</p>`).join('')}<div class="abcta"><a class="btn pink big" href="index.html#offer">Join Shruti: Your Guide</a></div>${polHtml}</div>`;

// Contact
const CI={telegram:'<circle cx="12" cy="12" r="12" fill="#27A7E7"/><path d="M5.4 11.8l11.2-4.3c.5-.2 1 .1.8.9l-1.9 9c-.1.6-.5.8-1 .5l-2.8-2.1-1.4 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.3-4.8c.2-.2 0-.3-.3-.1l-6.6 4.1-2.8-.9c-.6-.2-.6-.6.1-.9z" fill="#fff"/>',discussion:'<circle cx="12" cy="12" r="12" fill="#27A7E7"/><path d="M6.5 7.5h11v7h-6l-3 2.5v-2.5h-2z" fill="#fff"/>',instagram:'<defs><linearGradient id="ig" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#FEDA75"/><stop offset=".35" stop-color="#FA7E1E"/><stop offset=".6" stop-color="#D62976"/><stop offset=".85" stop-color="#962FBF"/><stop offset="1" stop-color="#4F5BD5"/></linearGradient></defs><rect width="24" height="24" rx="6" fill="url(#ig)"/><rect x="5" y="5" width="14" height="14" rx="4" fill="none" stroke="#fff" stroke-width="1.7"/><circle cx="12" cy="12" r="3.3" fill="none" stroke="#fff" stroke-width="1.7"/><circle cx="16.3" cy="7.7" r="1" fill="#fff"/>',mail:'<rect x="2" y="5" width="20" height="14" rx="2" fill="#fff"/><path d="M2 7v10.5A1.5 1.5 0 003.5 19H6.5v-8.5z" fill="#4285F4"/><path d="M22 7v10.5a1.5 1.5 0 01-1.500 1.500H17.500v-8.500z" fill="#34A853"/><path d="M2 7l10 7.500L22 7v-.5A1.500 1.500 0 0020.500 5H18l-6 4.500L6 5H3.500A1.500 1.500 0 002 6.500z" fill="#EA4335"/>'};
const cl=[['telegram','Telegram Group',L.telegram],['discussion','Discussion Group',L.discussion],['instagram','Instagram',L.instagram],['mail','Email','mailto:'+S.email]];
$('#contact').innerHTML=`<div class="wrap"><h2>Get in Touch</h2><div class="cgrid"><div class="cl"><img class="clogo" src="${S.logo}" alt="Shruti: Your Guide logo"><p class="ctag">${esc(S.tagline)}</p>${S.msg.map(t=>`<p>${esc(t)}</p>`).join('')}</div>
<div class="cr"><div class="cicons">${cl.map(c=>`<a href="${c[2]}" ${c[0]=='mail'?'':'target="_blank" rel="noopener"'}><svg viewBox="0 0 24 24">${CI[c[0]]}</svg><span>${c[1]}</span></a>`).join('')}</div>
<form id="cf"><h3>Contact Me</h3><input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off"><label>Name <span class="req" aria-hidden="true">*</span><input name="name" required></label><label>Email <span class="req" aria-hidden="true">*</span><input name="email" type="email" required></label><label>Phone Number<input name="phone" type="tel"></label><label>City<input name="city"></label><label>Your Message <span class="req" aria-hidden="true">*</span><textarea name="message" rows="4" required></textarea></label><p class="reqn"><span class="req">*</span> Compulsory fields</p><button class="btn pink" type="submit">Send</button><p id="cs" role="status"></p></form></div></div></div>`;
$('#cf').onsubmit=async e=>{e.preventDefault();const f=e.target,b=f.querySelector('button'),st=$('#cs'),d=Object.fromEntries(new FormData(f));b.disabled=true;st.textContent='Sending…';
 const fb=()=>{const body=`Name: ${d.name}\nEmail: ${d.email}\nPhone: ${d.phone||''}\nCity: ${d.city||''}\n\n${d.message}`;st.innerHTML=`Could not send it from this page. <a href="mailto:${S.email}?subject=${encodeURIComponent('Message from the website')}&body=${encodeURIComponent(body)}">Click here to send it by email instead</a>.`};
 try{const k=S.formKey,r=await fetch(k?'https://api.web3forms.com/submit':'https://formsubmit.co/ajax/'+S.email,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(k?{access_key:k,subject:'New message from Shruti: Your Guide website',from_name:'Shruti: Your Guide website',...d}:{...d,_subject:'New message from Shruti: Your Guide website',_template:'table',_captcha:'false'})});const j=await r.json();if(!r.ok||String(j.success)!=='true')throw 0;f.reset();st.textContent='Thank you! Your message has been sent.'}
 catch(_){fb()}b.disabled=false};

// How to join + checkout pop-ups
const PLK='<a href="about.html#policy-terms" target="_blank" rel="noopener">Terms &amp; Conditions</a>, <a href="about.html#policy-refund" target="_blank" rel="noopener">Refund Policy</a> and <a href="about.html#policy-disclaimer" target="_blank" rel="noopener">Disclaimer</a>';
const TG='<a href="https://t.me/SYG_guidedesk_bot" target="_blank" rel="noopener">@SYG_guidedesk_bot</a>';
document.body.insertAdjacentHTML('beforeend',`<dialog id="how" class="mdl" aria-labelledby="howt"><h2 id="howt">HOW TO JOIN A TARGET SERIES</h2><p>Joining a Target Series at Shruti: Your Guide is simple. Just follow these steps to get started!</p>
<h3>Step 1: Select Your Exam</h3><p>Choose your preferred examination category:</p><ul><li>SSC</li><li>Railway</li></ul>
<h3>Step 2: Choose Your Target Series</h3><p>Explore the currently active Target Series and select the one you wish to join.</p>
<h3>Step 3: Check the Study Plan</h3><p>Want to know what you'll be studying? Click on View Plan to explore the complete study schedule, daily targets and programme details before purchasing.</p>
<h3>Step 4: Click on Join Now</h3><p>Once you've selected your preferred Target Series, click on Join Now to proceed to the payment page.</p>
<h3>Step 5: Complete Your Payment</h3><p>You will be redirected to our secure payment gateway, Razorpay.</p><p>Choose your preferred payment method and complete the transaction.</p>
<h3>Step 6: Get Your Confirmation Email</h3><p>Once your payment is successfully approved, you will receive a confirmation email containing:</p><ul><li>Name of the Target Series purchased.</li><li>Programme validity and access duration.</li><li>Confirmation of your successful purchase.</li><li>Instructions regarding your private Telegram group access.</li></ul>
<h3>Step 7: Get Access to Your Private Telegram Group</h3><p>After successful payment, you will be automatically redirected to Telegram.</p><p>Please wait for approximately 2 minutes.</p><p>Do not press the back button or close the page during this process.</p><p>You will be redirected to Telegram, where you can access your private Target Series group.</p><p>Join the group and start following your daily targets!</p>
<h3>Didn't Receive Your Group Access?</h3><p>Don't worry! If you haven't received your private group invitation, please share the following:</p><ul><li>Your payment confirmation email.</li><li>A screenshot of your successful payment.</li></ul><p>Contact us through either of these channels:</p><p>Email: ${S.email}<br>Telegram: ${TG}</p><p>After verifying your payment, we will provide your private group invitation link within 24 hours.</p>
<h3>You're All Set!</h3><p>Welcome to Shruti: Your Guide!</p><p>Stay consistent, follow your targets and keep moving towards your dream government job.</p><div class="obtn"><button class="btn pink x" type="button">Close</button></div></dialog>
<dialog id="cko" class="mdl" aria-labelledby="ckot"><h2 id="ckot">IMPORTANT – PLEASE READ BEFORE PAYMENT</h2><p class="cks"></p><ul><li>Make sure Telegram is installed and you are already logged in on your phone or laptop.</li><li>After successful payment, wait for 1–2 minutes. Do not press the back button or close the page. You will be automatically redirected to your private Telegram group.</li></ul>
<h3>Facing any technical issues?</h3><p>If you don't receive access after payment, share your payment screenshot and confirmation email with us:</p><p>Email: ${S.email}<br>Telegram: ${TG}</p><p>After payment verification, your group invitation link will be provided within 24 hours.</p>
<label class="ck"><input type="checkbox" id="ck1"><span>I have read the instructions above.</span></label><label class="ck"><input type="checkbox" id="ck2"><span>I have read and agree to the ${PLK}.</span></label>
<div class="obtn"><button class="btn ghost dk x" type="button">Cancel</button><button class="btn pink" id="ckgo" type="button" disabled>Proceed</button></div></dialog>`);
{const ck=[$('#ck1'),$('#ck2')],go=$('#ckgo');let u='';const sy=()=>go.disabled=!ck.every(c=>c.checked);ck.forEach(c=>c.onchange=sy);
 window.openCko=(label,url)=>{ck.forEach(c=>c.checked=false);sy();u=url||'';$('#cko .cks').textContent=label;$('#cko').showModal()};
 go.onclick=()=>{$('#cko').close();if(u)location.assign(u);else toast('Payment link coming soon')};
 document.querySelectorAll('dialog.mdl .x').forEach(b=>b.onclick=()=>b.closest('dialog').close());
 document.querySelectorAll('.howbtn').forEach(b=>b.onclick=()=>$('#how').showModal())}

// Story + laptop
$('#sc').textContent=S.scene;
const clamp=v=>Math.max(0,Math.min(1,v));
function openLap(){}
if(pg=='about')openLap();

// Road scene
(()=>{const cv=$('#cv'),x=cv.getContext('2d'),logo=new Image();logo.src=S.logo;let W,H,vis=true;
const rs=()=>{const D=devicePixelRatio||1;W=cv.clientWidth;H=cv.clientHeight;cv.width=W*D;cv.height=H*D;x.setTransform(D,0,0,D,0,0)};rs();addEventListener('resize',rs);
new IntersectionObserver(e=>vis=e[0].isIntersecting).observe(cv);
const rw=()=>Math.min(W*.16,150),hb=()=>Math.min(W,H*1.2)*.085,hh=t=>hb()*(1-.3*t),RY=()=>H*.07;
const Bz=(a,b,c,d,t)=>{const u=1-t;return u*u*u*a+3*u*u*t*b+3*u*t*t*c+t*t*t*d},dBz=(a,b,c,d,t)=>{const u=1-t;return 3*u*u*(b-a)+6*u*t*(c-b)+3*t*t*(d-c)};
const P=(s,t,o=0)=>{const a=[.5*W,.5*W,(.5+s*.3)*W,(.5+s*.3)*W],b=[.97*H,.6*H,.45*H,.46*H];const px=Bz(a[0],a[1],a[2],a[3],t),py=Bz(b[0],b[1],b[2],b[3],t),dx=dBz(a[0],a[1],a[2],a[3],t),dy=dBz(b[0],b[1],b[2],b[3],t),l=Math.hypot(dx,dy)||1;return{x:px-dy/l*o,y:py+dx/l*o}};
const gt={o:0},claw={x:.5*W,len:50,g:0,follow:null},crowd=[],walkers=[];
let gi=0;const mk=t=>({t,off:(((gi++*.618)%1)-.5)*.56,ph:Math.random()*6,sp:.95+Math.random()*.1,side:1,c:0,a:1});
for(let i=0;i<40;i++)crowd.push(mk(.02+i/40*.97));
const fpos=f=>f.held?{x:claw.x,y:RY()+claw.len+f.h*1.04+2}:P(f.side,f.t,f.off*rw()*(1-.4*f.t));
const tw=(o,k,to,ms,lin)=>new Promise(r=>{const a=o[k],t0=performance.now();(function s(t){const p=clamp((t-t0)/ms),e=lin?p:p*p*(3-2*p);o[k]=a+(to-a)*e;p<1?requestAnimationFrame(s):r()})(t0)});
const sl=ms=>new Promise(r=>setTimeout(r,ms));
const C=S.captions,cp=$('#sc');let ct;cp.textContent=S.scene;
const cap=t=>{clearTimeout(ct);cp.style.opacity=0;ct=setTimeout(()=>{cp.textContent=t;cp.style.opacity=1},250)};
async function cycle(){const c=crowd.filter(f=>f.t>.25&&f.t<.6&&!f.frozen),f=c[Math.floor(Math.random()*c.length)];if(!f){await sl(700);return cycle()}
 f.frozen=true;f.you=true;const p=P(1,f.t,f.off*rw()*(1-.4*f.t));f.h=hh(f.t)*1.25;
 await tw(claw,'x',p.x,1300);await tw(claw,'len',p.y-f.h*1.04-2-RY(),900);await tw(claw,'g',1,300);f.held=true;cap(C[0]);
 await tw(claw,'len',50,900);const d=P(-1,.2,0),dh=hh(.2)*1.25;
 await tw(claw,'x',d.x,1500);await tw(claw,'len',d.y-dh*1.04-2-RY(),900);await tw(claw,'g',0,300);cap(C[1]);
 crowd.splice(crowd.indexOf(f),1);crowd.push(mk(.03));Object.assign(f,{held:false,frozen:false,side:-1,t:.2,off:0,walk:true});walkers.push(f);tw(f,'c',1,600);
 await tw(claw,'len',50,700);claw.follow=f;cap(C[2]);let i=0;
 for(const h of[.42,.63,1]){await tw(f,'t',h,(h-f.t)*9000,1);f.walk=false;
  if(h<1){cap(C[i?5:3]);f.fall=0;tw(f,'fall',1,350);await sl(900);claw.follow=null;const q=P(-1,h,0);await tw(claw,'x',q.x,700);await tw(claw,'len',q.y-14-RY(),800);await tw(claw,'g',1,250);
   f.h=hh(h)*1.25;f.fall=0;f.held=true;if(!i)cap(C[4]);await tw(claw,'len',claw.len-28,500);const nt=h+.07,q2=P(-1,nt,0);await tw(claw,'x',q2.x,600);await tw(claw,'len',q2.y-hh(nt)*1.25*1.04-2-RY(),400);await tw(claw,'g',0,250);
   f.held=false;f.t=nt;f.walk=true;await tw(claw,'len',50,600);claw.follow=f;i++}}
 cap(C[6]);if(gt.o<1)await tw(gt,'o',1,1100);f.walk=true;f.in=0;await tw(f,'in',1,1300);f.walk=false;
 walkers.splice(walkers.indexOf(f),1);claw.follow=null;await tw(claw,'x',W/2,1200);cap(S.scene);await sl(2000);cycle()}
const run=()=>cycle().catch(()=>setTimeout(run,1200));setTimeout(()=>{rs();run()},500);
function drawHole(e,R,n){const hg=x.createRadialGradient(e.x,e.y,0,e.x,e.y,R*.9);hg.addColorStop(0,'#000');hg.addColorStop(.7,'#000');hg.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=hg;x.beginPath();x.ellipse(e.x,e.y,R*.9,R*.55,0,0,7);x.fill();
 x.strokeStyle='rgba(231,160,181,.5)';x.lineWidth=2;for(let i=0;i<3;i++){x.beginPath();x.ellipse(e.x,e.y,R*(.25+i*.18),R*(.14+i*.1),0,n/700+i,n/700+i+3.2);x.stroke()}}
function drawPits(R){for(const h of[.42,.63]){const p=P(-1,h),pw=R*.3,ph=R*.11;let g=x.createLinearGradient(0,p.y-ph,0,p.y+ph*1.4);g.addColorStop(0,'#555');g.addColorStop(1,'#2a2a2a');x.fillStyle=g;x.beginPath();x.ellipse(p.x,p.y+ph*.2,pw*1.12,ph*1.25,0,0,7);x.fill();
 g=x.createRadialGradient(p.x,p.y-ph*.3,pw*.1,p.x,p.y,pw);g.addColorStop(0,'#000');g.addColorStop(1,'#0b0b0b');x.fillStyle=g;x.beginPath();x.ellipse(p.x,p.y,pw,ph,0,0,7);x.fill();
 x.strokeStyle='rgba(255,255,255,.28)';x.lineWidth=2;x.beginPath();x.ellipse(p.x,p.y+ph*.2,pw*1.12,ph*1.25,0,.15,Math.PI-.15);x.stroke()}}
const LG=S.logos.map(l=>{const im=new Image();im.src=l[1];return im});
function drawGate(e,R,n){const ow=R*.5,oh=R*.78,hw=ow/2,fr=R*.07,by=e.y+R*.12,cx=e.x,cy=by-oh+hw,o=gt.o;
 x.fillStyle='rgba(0,0,0,.3)';x.beginPath();x.ellipse(cx,by+3,ow*.95,6,0,0,7);x.fill();
 x.fillStyle='#a58759';x.fillRect(cx-ow*.8,by-5,ow*1.6,6);x.fillStyle='#b99a6e';x.fillRect(cx-ow*.68,by-10,ow*1.36,5);
 let g=x.createLinearGradient(cx-hw-fr,0,cx+hw+fr,0);g.addColorStop(0,'#b58a5c');g.addColorStop(.5,'#d9b588');g.addColorStop(1,'#b58a5c');x.fillStyle=g;x.strokeStyle='#7d5d3a';x.lineWidth=2;
 x.beginPath();x.roundRect(cx-hw-fr,by-oh-fr,ow+2*fr,oh+fr,[hw+fr,hw+fr,0,0]);x.fill();x.stroke();
 x.strokeStyle='rgba(110,80,45,.6)';x.lineWidth=1.2;for(let i=1;i<8;i++){const a=Math.PI+i*Math.PI/8;x.beginPath();x.moveTo(cx+Math.cos(a)*hw,cy+Math.sin(a)*hw);x.lineTo(cx+Math.cos(a)*(hw+fr),cy+Math.sin(a)*(hw+fr));x.stroke()}
 x.save();x.beginPath();x.roundRect(cx-hw,by-oh,ow,oh,[hw,hw,0,0]);x.clip();
 g=x.createLinearGradient(0,by-oh,0,by);g.addColorStop(0,'#fff6dc');g.addColorStop(1,'#c79a55');x.fillStyle=g;x.fillRect(cx-hw,by-oh,ow,oh);
 const dw=hw*(1-o*.86),iy=o*oh*.06;
 for(const s2 of[-1,1]){const x0=cx+s2*hw,x1=x0-s2*dw,P2=(u,v)=>{const yt=by-oh+iy*u,yb=by-iy*u;return[x0+(x1-x0)*u,yt+(yb-yt)*v]};
  const lg=x.createLinearGradient(x0,0,x1,0);lg.addColorStop(0,'#3b2314');lg.addColorStop(1,'#6e4629');x.fillStyle=lg;x.beginPath();x.moveTo(x0,by-oh-4);x.lineTo(x1,by-oh+iy);x.lineTo(x1,by-iy);x.lineTo(x0,by);x.closePath();x.fill();
  if(dw>6){x.strokeStyle='rgba(0,0,0,.35)';x.lineWidth=1;for(const u of[.33,.66]){const a=P2(u,0),b2=P2(u,1);x.beginPath();x.moveTo(a[0],a[1]);x.lineTo(b2[0],b2[1]);x.stroke()}
   for(const[v0,v1]of[[.07,.45],[.53,.93]]){const p=[P2(.14,v0),P2(.86,v0),P2(.86,v1),P2(.14,v1)];x.fillStyle='rgba(0,0,0,.22)';x.strokeStyle='rgba(255,215,150,.4)';x.beginPath();p.forEach((q,i)=>i?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1]));x.closePath();x.fill();x.stroke()}
   const k=P2(.82,.55);x.fillStyle='#d9ae3c';x.beginPath();x.arc(k[0],k[1],Math.max(2,R*.024),0,7);x.fill()}}
 x.restore();pill('Officer',cx,by-oh-fr-16);
 const sz=W<600?34:Math.max(38,Math.min(R*.36,62)),rows=W<600?[[0,1],[2,3],[4,5],[6]]:[[0,1,2,3],[4,5,6]],gp=W<600?5:10,top0=by-oh-fr-32;
 rows.forEach((r,ri)=>{const ws=r.map(i=>{const m=LG[i],ar=m.naturalWidth?m.naturalWidth/m.naturalHeight:1;return[sz*Math.min(Math.max(ar,1),2.2),ar]});const tot=ws.reduce((a,c)=>a+c[0],0)+gp*(r.length-1);let lx=Math.max(tot/2+4,Math.min(W-tot/2-4,cx-(W<600?0:30)))-tot/2;
  r.forEach((i,k)=>{const im=LG[i],[bw,ar]=ws[k],bh=sz,px=lx+bw/2,py=top0-8-sz*.5-ri*(sz+gp+2)+Math.sin(n/650+i*1.3+ri)*3;lx+=bw+gp;if(!im.naturalWidth)return;
   x.save();x.shadowColor='rgba(0,0,0,.35)';x.shadowBlur=14;x.shadowOffsetY=6;x.fillStyle='#fff';x.beginPath();x.roundRect(px-bw/2,py-bh/2,bw,bh,ar<1.25?bh/2:bh*.2);x.fill();x.restore();
   x.save();x.beginPath();x.roundRect(px-bw/2,py-bh/2,bw,bh,ar<1.25?bh/2:bh*.2);x.clip();const sc=Math.min(bw*.86/im.naturalWidth,bh*.86/im.naturalHeight);x.drawImage(im,px-im.naturalWidth*sc/2,py-im.naturalHeight*sc/2,im.naturalWidth*sc,im.naturalHeight*sc);x.restore()})})}
function holeLabel(e,R){const fs=Math.max(10,Math.min(17,R*.12));x.fillStyle='#fff';x.font=`800 ${fs}px Manrope,sans-serif`;x.textAlign='center';x.fillText('Competitive Exams',e.x,e.y-fs*.1);x.fillText('LOOP ➰',e.x,e.y+fs*1.25)}
function fig(px,py,h,c,ph,o){x.save();x.translate(px,py);if(o.fall)x.rotate(Math.PI/2*o.fall);const v=17+238*c;x.strokeStyle=x.fillStyle=`rgb(${v},${v},${v})`;x.lineWidth=h*.11;x.lineCap='round';
 const sw=o.held?0:Math.sin(ph)*h*.14,hy=o.held?-h*1.0:-h*.42;x.beginPath();x.arc(0,-h*.88,h*.14,0,7);x.fill();x.beginPath();x.moveTo(0,-h*.72);x.lineTo(0,-h*.36);x.moveTo(0,-h*.36);x.lineTo(sw,0);x.moveTo(0,-h*.36);x.lineTo(-sw,0);x.moveTo(0,-h*.66);x.lineTo(-h*.2-sw*.4,hy);x.moveTo(0,-h*.66);x.lineTo(h*.2+sw*.4,hy);x.stroke();x.restore();
 if(o.you){const ly=py-(o.fall?h*.3:h*1.3);x.fillStyle='#E7A0B5';x.beginPath();x.roundRect(px-18,ly-9,36,17,9);x.fill();x.fillStyle='#111';x.font='700 11px Manrope,sans-serif';x.textAlign='center';x.fillText('YOU',px,ly+3)}}
const pill=(t,px,py)=>{x.font='700 12px Manrope,sans-serif';const w=x.measureText(t).width+20;px=Math.max(w/2+4,Math.min(W-w/2-4,px));x.fillStyle='#E7A0B5';x.beginPath();x.roundRect(px-w/2,py-11,w,22,11);x.fill();x.fillStyle='#111';x.textAlign='center';x.fillText(t,px,py+4)};
function road(s,col){x.strokeStyle=col;x.lineCap='round';let q=P(s,0);for(let i=1;i<=40;i++){const p=P(s,i/40);x.lineWidth=rw()*(1-.4*i/40);x.beginPath();x.moveTo(q.x,q.y);x.lineTo(p.x,p.y);x.stroke();q=p}}
let last=performance.now();
(function frame(n){requestAnimationFrame(frame);const dt=Math.min(50,n-last);last=n;if(!vis)return;
 for(const f of crowd)if(!f.frozen){f.t+=.03*f.sp*dt/1000;if(f.t>1)f.t=.02;f.ph+=dt*.01}
 for(const f of walkers)if(f.walk)f.ph+=dt*.012;
 if(claw.follow){const p=fpos(claw.follow);claw.x+=(p.x-claw.x)*.06}
 const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#8e9197');g.addColorStop(1,'#c8cacd');x.fillStyle=g;x.fillRect(0,0,W,H);
 road(1,'#ebe6dc');road(-1,'#171717');
 const e1=P(1,1),e2=P(-1,1),R=rw();
 drawHole(e1,R,n);drawPits(R);drawGate(e2,R,n);
 const all=[...crowd,...walkers].sort((a,b)=>fpos(a).y-fpos(b).y);
 for(const f of all){const p=fpos(f),h=f.held?f.h:hh(f.t)*(f.you?1.25:.88),sc=f.side==1&&f.t>.9?clamp((1-f.t)/.1):1,n2=f.in||0;if(n2)p.y-=n2*R*.3;x.globalAlpha=(f.a??1)*Math.max(.15,sc)*(1-n2);fig(p.x,p.y,h*Math.max(.3,sc)*(1-.35*n2),f.c,f.ph,{you:f.you,fall:f.fall,held:f.held});x.globalAlpha=1}
 holeLabel(e1,R);const ry=RY(),ty=ry+claw.len;x.fillStyle='#333';x.fillRect(0,ry-4,W,5);
 x.strokeStyle='#222';x.lineWidth=2;x.beginPath();x.moveTo(claw.x,ry);x.lineTo(claw.x,ty-34);x.stroke();
 x.fillStyle='#111';x.beginPath();x.roundRect(claw.x-12,ry-10,24,12,3);x.fill();
 x.fillStyle='#1b1b1b';x.beginPath();x.roundRect(claw.x-22,ty-62,44,34,8);x.fill();
 x.save();x.beginPath();x.arc(claw.x,ty-45,13,0,7);x.clip();if(logo.complete&&logo.naturalWidth)x.drawImage(logo,claw.x-13,ty-58,26,26);x.restore();
 x.strokeStyle='#E7A0B5';x.lineWidth=3.5;x.lineCap='round';for(const s of[-1,1]){const sp=22*(1-claw.g)+6*claw.g;x.beginPath();x.moveTo(claw.x+s*16,ty-30);x.quadraticCurveTo(claw.x+s*sp*1.3,ty-10,claw.x+s*sp*.6,ty+4);x.stroke()}
 pill('Shruti: Your Guide',claw.x,ty-72<ry+14?ty-72:ty-72);
 const lb=(a,b)=>0})(last);
})();
